# Proyecto multicore

- Aaron González
- David arguedas

# Instrucciones

## Ejecución con un solo núcleo

Para correrlo con un solo núcleo utilizar el siguiente comando

# Linux

```bash
./imager --num-processess 1 <imagen>
```

# Windows

```bash
python imager --num-processess 1 <imagen>
```
